﻿Public Class Nodez
    Public time As Long
    Public endtime As Long
    Public text As String
    Public name As String

    Public Sub New(p1 As Long, p2 As Long, p3 As String)
        time = p1
        endtime = p2
        text = p3
    End Sub

    Public Sub New(p1 As Long, p2 As Long, p3 As String, p4 As String)
        time = p1
        endtime = p2
        text = p3
        name = p4
    End Sub

    Public Sub New()
    End Sub
End Class
