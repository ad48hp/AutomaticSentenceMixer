﻿Imports System.IO
Imports System.Xml
'Imports Fiddler

Public Class Form1
    Public krok As Integer
    Public myurl As String
    Public done As Boolean
    Public mnam2 As String
    Public nodezz As New List(Of Nodez)
    Public allwordz As List(Of String)

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        'FiddlerApplication.Shutdown()
        Dim mywriter As New StreamWriter("options")
        mywriter.WriteLine(TextBox8.Text)
        mywriter.WriteLine(TextBox2.Text)
        mywriter.WriteLine(TextBox3.Text)
        mywriter.WriteLine(TextBox5.Text)
        mywriter.WriteLine(TextBox6.Text)
        mywriter.WriteLine(TextBox7.Text)
        mywriter.WriteLine(CheckBox1.Checked)
        mywriter.WriteLine(CheckBox2.Checked)
        mywriter.WriteLine(ComboBox1.SelectedIndex)
        mywriter.WriteLine(TextBox1.Text)
        mywriter.Close()
    End Sub

    Private Sub SortOptions(v1 As Boolean, v2 As Boolean)
        If v1 Then
            TextBox1.Text = TextBox1.Text.Replace(",", " ").Replace(".", "")
            While TextBox1.Text.Contains("  ")
                TextBox1.Text = TextBox1.Text.Replace("  ", " ")
            End While
        End If
        If v2 Then
            TextBox2.Text = TextBox2.Text.Replace("http://www.youtube.com", "").Replace("https://www.youtube.com", "")
            While TextBox2.Text.StartsWith("//")
                TextBox2.Text = TextBox2.Text.Substring(1, TextBox2.Text.Length - 1)
            End While
            If Not TextBox2.Text.StartsWith("/") Then
                TextBox2.Text = "/" + TextBox2.Text
            End If
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Shown
        If Not Directory.Exists(Application.StartupPath + "/output") Then
            Directory.CreateDirectory(Application.StartupPath + "/output")
        End If
        If File.Exists(Application.StartupPath + "/options") Then
            Dim myreader As New StreamReader("options")
            TextBox8.Text = myreader.ReadLine()
            TextBox2.Text = myreader.ReadLine()
            TextBox3.Text = myreader.ReadLine()
            TextBox5.Text = myreader.ReadLine()
            TextBox6.Text = myreader.ReadLine()
            TextBox7.Text = myreader.ReadLine()
            CheckBox1.Checked = myreader.ReadLine()
            CheckBox2.Checked = myreader.ReadLine()
            ComboBox1.SelectedIndex = myreader.ReadLine()
            While Not myreader.EndOfStream
                Dim myline As String
                myline = myreader.ReadLine()
                If Not myline = "" Then
                    TextBox1.Text += myline
                    TextBox1.Text += Environment.NewLine
                End If
            End While
            myreader.Close()
        Else
            ComboBox1.SelectedIndex = 0
        End If
        Dim allcontrols As List(Of Control)
        allcontrols = GetControls(Me)
        For Each item In allcontrols
            If TypeOf item Is TextBox AndAlso DirectCast(item, TextBox).Multiline Then
                AddHandler DirectCast(item, TextBox).KeyDown, AddressOf slttext
            End If
        Next
        TextBox1.SelectionStart = TextBox1.Text.Length
        TextBox1.SelectionLength = 0
        'AddHandler FiddlerApplication.AfterSessionComplete, AddressOf sesscomp
        'FiddlerApplication.Startup(8888, False, True, False)
    End Sub

    Public Function GetControls(myctl As Object) As List(Of Control)
        Dim mylist As List(Of Control)
        mylist = New List(Of Control)
        For Each mycontrol In myctl.Controls
            mylist.AddRange(GetControls(mycontrol))
            mylist.Add(mycontrol)
        Next
        Return mylist
    End Function

    Private Sub slttext(sender As Object, e As KeyEventArgs)
        If e.Control AndAlso e.KeyCode = Keys.A Then
            Dim txt As TextBox
            txt = DirectCast(sender, TextBox)
            txt.SelectionStart = 0
            txt.SelectionLength = txt.Text.Length
        End If
    End Sub

    'Private Sub sesscomp(suss As Session)
    'If krok = 0 AndAlso suss.fullUrl.Contains("youtube.com/api/timedtext") Then
    'Dim mywriter69 As New StreamWriter(TextBox3.Text + "/" + mnam2 + ".xml")
    'suss.GetRequestBodyAsString()
    'mywriter69.Close()
    'End If
    'End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim mnpath As String
        mnpath = Application.StartupPath + "/output"
        If Not Directory.Exists(TextBox3.Text) Then
            If MessageBox.Show("Path doesn't exist. Do you want to create it ?", "Error", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) Then
                Directory.CreateDirectory(TextBox3.Text)
            End If
        End If
        If TextBox8.Text = "" OrElse Not File.Exists(TextBox8.Text) Then
            MessageBox.Show("FFMPEG path is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
        If TextBox5.Text = "" Then
            TextBox5.Text = "0"
        End If
        If TextBox6.Text = "" Then
            TextBox6.Text = "0"
        End If
        If TextBox9.Text = "" Then
            TextBox9.Text = "30"
        End If
        TextBox5.Text = TextBox5.Text.Replace(".", ",")
        TextBox6.Text = TextBox6.Text.Replace(".", ",")
        TextBox9.Text = TextBox9.Text.Replace(".", ",")
        If Not Double.TryParse(TextBox5.Text, 0) Then
            MessageBox.Show("Start time isn't a number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
        If Not Double.TryParse(TextBox6.Text, 0) Then
            MessageBox.Show("End time isn't a number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
        If Not Integer.TryParse(TextBox7.Text, 0) OrElse Not Integer.Parse(TextBox7.Text, 0) > 0 Then
            MessageBox.Show("Max. number isn't an integer bigger than 0.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
        If ComboBox1.SelectedIndex = 2 AndAlso Not Double.TryParse(TextBox9.Text, 1) Then
            MessageBox.Show("Seek difference isn't a number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
        If Directory.Exists(TextBox3.Text) AndAlso Not TextBox8.Text = "" AndAlso File.Exists(TextBox8.Text) AndAlso Double.TryParse(TextBox5.Text, 1) AndAlso Double.TryParse(TextBox6.Text, 1) AndAlso Double.TryParse(TextBox7.Text, 1) AndAlso (Not ComboBox1.SelectedIndex = 2 OrElse Double.TryParse(TextBox9.Text, 1)) Then
            krok = 0
            If Not TextBox2.Text = "" Then
                'WebBrowser1.Navigate("https://youtube.com" + TextBox2.Text)
            End If
            ProcessSentences(mnpath, False, True)
            krok = 1
        End If
    End Sub

    Public Function ProcessSentences(mnpath As String, checkxmlonline As Boolean, extract As Boolean) As List(Of IEnumerable(Of Object))
        Dim mdr As FileInfo() = New DirectoryInfo(TextBox3.Text).GetFiles()
        Dim lists As List(Of IEnumerable(Of Object))
        lists = New List(Of IEnumerable(Of Object))
        Dim allwords As List(Of Nodez)
        allwords = New List(Of Nodez)
        Dim processedwords As List(Of Nodez)
        processedwords = New List(Of Nodez)
        Dim ttxt As List(Of String)
        ttxt = CheckWantedWords()
        For Each item In mdr
            If item.Extension.ToLower().Replace(".", "") = "mp4" Then
                Dim mnam As String
                mnam = Path.GetFileNameWithoutExtension(item.FullName)
                If checkxmlonline Then
                    While Not File.Exists(TextBox3.Text + "/" + mnam + ".xml")
                        mnam2 = mnam
                        myurl = "https://youtube.com/watch?v=" + mnam
                        krok = 0
                        WebBrowser1.Navigate(myurl)
                        While Not krok = 1
                            Application.DoEvents()
                        End While
                    End While
                End If
                If File.Exists(TextBox3.Text + "/" + mnam + ".xml") Then
                    nodezz.Clear()
                    Dim myxml As XDocument = XDocument.Load(TextBox3.Text + "/" + mnam + ".xml")
                    Dim mynodes As List(Of XElement)
                    mynodes = myxml.Descendants().Where(Function(z) z.Name.LocalName.ToLower() = "s").ToList()
                    For Each ndz In mynodes
                        Dim mt As Long
                        mt = 0
                        Dim mt2 As Long
                        mt2 = 0
                        If Not ndz.Attribute("t") Is Nothing AndAlso Not ndz.Attribute("t").Value = "" Then
                            mt += Long.Parse(ndz.Attribute("t").Value)
                        End If
                        Dim ndz2 As XElement
                        ndz2 = ndz.NodesAfterSelf().OfType(Of XElement).FirstOrDefault(Function(z) z.Name.LocalName = "s")
                        If Not ndz2 Is Nothing AndAlso Not ndz2.Attribute("t") Is Nothing AndAlso Not ndz2.Attribute("t").Value = "" Then
                            mt2 += Long.Parse(ndz2.Attribute("t").Value)
                        End If
                        mt += Long.Parse(ndz.Parent.Attribute("t"))
                        mt2 += Long.Parse(ndz.Parent.Attribute("t"))
                        Dim myndz As New Nodez(mt, mt2, ndz.Value.ToLower().Replace(" ", ""))
                        nodezz.Add(myndz)
                    Next
                    allwords.AddRange(nodezz)
                    Dim i31 As Integer
                    i31 = 1
                    For Each mndz In ttxt
                        Dim nodezzi As List(Of Nodez)
                        nodezzi = New List(Of Nodez)
                        Dim curi As Integer
                        curi = 1
                        Dim nodezzi31 As List(Of Nodez)
                        nodezzi31 = New List(Of Nodez)
                        For Each nodezi2 In nodezz
                            If nodezi2.text = mndz.Replace(vbCrLf, "").ToLower().Replace(" ", "") Then
                                nodezzi.Add(nodezi2)
                                curi += 1
                            End If
                            If CheckBox1.Checked AndAlso mndz.Replace(vbCrLf, "").ToLower().Replace(" ", "").Contains(nodezi2.text) Then
                                nodezzi31.Add(nodezi2)
                            End If
                            If curi > Integer.Parse(TextBox7.Text) Then
                                Exit For
                            End If
                        Next
                        If curi < Integer.Parse(TextBox7.Text) - 1 Then
                            For Each nodezi81 In nodezzi31
                                nodezzi.Add(nodezi81)
                                curi += 1
                                If curi > Integer.Parse(TextBox7.Text) Then
                                    Exit For
                                End If
                            Next
                        End If
                        processedwords.AddRange(nodezzi)
                        If extract Then
                            For Each nodezi In nodezzi
                                While File.Exists(mnpath + "/" + i31.ToString() + ".mp4")
                                    i31 += 1
                                End While
                                Dim mstartinfo As New ProcessStartInfo
                                mstartinfo.FileName = TextBox8.Text
                                Dim tm1 As TimeSpan
                                Dim tm2 As TimeSpan
                                tm1 = TimeSpan.FromMilliseconds(nodezi.time)
                                tm1.Add(TimeSpan.FromSeconds(Double.Parse(TextBox5.Text)))
                                tm2.Add(TimeSpan.FromSeconds(Double.Parse(TextBox5.Text) + Double.Parse(TextBox6.Text)))
                                'tm2 = TimeSpan.FromMilliseconds(nodezi.endtime - nodezi.time)
                                'If tm2.TotalMilliseconds <= 0 Then
                                tm2 = TimeSpan.FromMilliseconds(1024)
                                'End If
                                Dim canprocess As Boolean
                                canprocess = True
                                Dim myname As String
                                If Integer.Parse(TextBox7.Text) = 1 Then
                                    myname = i31.ToString()
                                Else
                                    Dim i36 As Integer
                                    i36 = 1
                                    While File.Exists(mnpath + "/" + nodezi.text + i36.ToString() + ".mp4")
                                        i36 += 1
                                    End While
                                    If i36 > Integer.Parse(TextBox7.Text) Then
                                        canprocess = False
                                    End If
                                    myname = nodezi.text + i36.ToString()
                                End If
                                If canprocess Then
                                    Select Case ComboBox1.SelectedIndex
                                        Case 0
                                            mstartinfo.Arguments = "-ss " + FormatMeDate(tm1, "ms") + " -i " + ChrW(34) + item.FullName + ChrW(34) + " -c copy -t " + FormatMeDate(tm2, "ms") + " " + ChrW(34) + mnpath + "/" + myname + ".mp4" + ChrW(34)
                                        Case 1
                                            mstartinfo.Arguments = "-i " + ChrW(34) + item.FullName + ChrW(34) + " -ss " + FormatMeDate(tm1, "ms") + " -c copy -t " + FormatMeDate(tm2, "ms") + " " + ChrW(34) + mnpath + "/" + myname + ".mp4" + ChrW(34)
                                        Case 2
                                            If tm1.TotalSeconds <= Double.Parse(TextBox9.Text) Then
                                                mstartinfo.Arguments = "-ss " + FormatMeDate(tm1, "ms") + " -i " + ChrW(34) + item.FullName + ChrW(34) + " -c copy -t " + FormatMeDate(tm2, "ms") + " " + ChrW(34) + mnpath + "/" + myname + ".mp4" + ChrW(34)
                                            Else
                                                mstartinfo.Arguments = "-ss " + FormatMeDate(tm1.Subtract(TimeSpan.FromSeconds(Double.Parse(TextBox9.Text))), "ms") + " -i " + ChrW(34) + item.FullName + ChrW(34) + " -ss " + FormatMeDate(TimeSpan.FromSeconds(Double.Parse(TextBox9.Text)), "ms") + " -c copy -t " + FormatMeDate(tm2, "ms") + " " + ChrW(34) + mnpath + "/" + myname + ".mp4" + ChrW(34)
                                            End If
                                    End Select
                                    Process.Start(mstartinfo).WaitForExit()
                                End If
                            Next
                        End If
                    Next
                    If False Then
                        Dim mstartinfo2 As New ProcessStartInfo
                        mstartinfo2.FileName = Application.StartupPath + "/ffmpeg.exe"
                        mstartinfo2.WorkingDirectory = Application.StartupPath
                        Dim i87 As Integer
                        i87 = 1
                        While i87 < i31
                            mstartinfo2.Arguments = ""
                            For i42 = i87 To i87 + 4
                                If i87 <= i31 Then
                                    mstartinfo2.Arguments += "-i " + i42.ToString() + ".mp4 "
                                End If

                            Next
                            mstartinfo2.Arguments += "-filter_complex " + ChrW(34)
                            For i42 = i87 To i87 + 4
                                If i87 <= i31 Then
                                    mstartinfo2.Arguments += "[" + (i42 - 1).ToString() + ":v]"
                                End If
                            Next
                            mstartinfo2.Arguments += "hstack,format=yuv420p[v];"
                            For i42 = i87 To i87 + 4
                                If i87 <= i31 Then
                                    mstartinfo2.Arguments += "[" + (i42 - 1).ToString() + ":a]"
                                End If
                            Next
                            mstartinfo2.Arguments += "amerge[a]" + ChrW(34) + " -map " + ChrW(34) + "[v]" + ChrW(34) + " -map " + ChrW(34) + "[a]" + ChrW(34) + " -c:v libx264 -crf 18 -ac 2 editz.mp4"
                            Process.Start(mstartinfo2).WaitForExit()
                            i87 += 4 + 1
                        End While
                    End If
                End If
            End If
        Next
        lists.Add(allwords)
        lists.Add(processedwords)
        lists.Add(ttxt)
        Return lists
    End Function

    Private Function CheckWantedWords() As List(Of String)
        Dim ttxt2 As String()
        ttxt2 = TextBox1.Text.ToLower().Split(New String() {" "}, StringSplitOptions.RemoveEmptyEntries)
        Dim ttxt As List(Of String)
        ttxt = New List(Of String)
        If True Then
            ttxt = New List(Of String)
            Dim containedwords As List(Of String)
            containedwords = New List(Of String)
            For Each myword2 In ttxt2
                Dim myword As String
                myword = NormalizeWord(myword2)
                If Not containedwords.Contains(myword) Then
                    containedwords.Add(myword)
                    ttxt.Add(myword)
                End If
            Next
        Else
            ttxt = New List(Of String)(ttxt2)
        End If
        Return ttxt
    End Function

    Private Function NormalizeWord(mw As String) As String
        Dim mw2 As String
        mw2 = mw.Replace(vbCrLf, "").ToLower().Replace(" ", "").Replace(Environment.NewLine, "")
        Dim mw3 As String
        mw3 = ""
        For i = 1 To mw2.Length
            If AscW(mw2(i - 1)) > 13 Then
                mw3 += mw2(i - 1)
            End If
        Next
        Return mw3
    End Function

    Private Function FormatMeDate(tm1 As TimeSpan, v As String) As String
        If v = "ms" Then
            Return Math.Floor(tm1.TotalHours).ToString().PadLeft(2, "0") + ":" + tm1.Minutes.ToString().PadLeft(2, "0") + ":" + tm1.Seconds.ToString().PadLeft(2, "0") + "." + tm1.Milliseconds.ToString().PadLeft(2, "0")
        End If
        If v = "s" Then
            Return Math.Floor(tm1.TotalHours).ToString().PadLeft(2, "0") + ":" + tm1.Minutes.ToString().PadLeft(2, "0") + ":" + tm1.Seconds.ToString().PadLeft(2, "0")
        End If
        Return tm1.ToString("hh:mm:ss")
    End Function

    Private Sub Form1_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load
        WebBrowser1.ScriptErrorsSuppressed = True
        AddHandler WebBrowser1.DocumentCompleted, AddressOf doccomp
    End Sub

    Private Sub doccomp(sender As Object, e As WebBrowserDocumentCompletedEventArgs)
        Select Case krok
            Case 0
                If e.Url.AbsoluteUri.Contains("youtube.com/watch?v=" + mnam2) Then
                    Dim mstop As New Stopwatch
                    Dim bt1 As HtmlElement
                    Dim bt2 As HtmlElement
                    bt1 = Nothing
                    bt2 = Nothing
                    mstop.Reset()
                    mstop.Start()
                    While mstop.ElapsedMilliseconds < 2000
                        Application.DoEvents()
                    End While
                    For Each item31 As HtmlElement In WebBrowser1.Document.All
                        If item31.GetAttribute("classname").Contains("ytp-play-button") Then
                            bt1 = item31
                        End If
                        If item31.GetAttribute("classname").Contains("ytp-subtitles-button") Then
                            bt2 = item31
                        End If
                    Next
                    done = False
                    Dim i As Integer
                    i = 1
                    While Not done
                        bt1.InvokeMember("click")
                        mstop.Reset()
                        mstop.Start()
                        While mstop.ElapsedMilliseconds < 2000
                            Application.DoEvents()
                        End While
                        bt2.InvokeMember("click")
                        mstop.Reset()
                        mstop.Start()
                        While mstop.ElapsedMilliseconds < 4600
                            Application.DoEvents()
                        End While
                        i += 1
                        If i > 5 Then
                            done = True
                        End If
                    End While
                    krok = 1
                End If
        End Select
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        TextBox9.ReadOnly = Not (DirectCast(sender, ComboBox).SelectedIndex = 2)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox10.Text = ""
        If False Then
            Dim processedwordz As List(Of String)
            processedwordz = New List(Of String)
            'For Each item92 As Nodez In mylists(1)
            'If Not processedwordz.Contains(item92.text) Then
            'processedwordz.Add(item92.text)
            'End If
            'Next
            processedwordz.Sort()
        End If
        If TextBox11.Text = "" Then
            ProcessAllWords()
        End If
        Dim sortedwanted As List(Of String)
        sortedwanted = New List(Of String)
        Dim wantedwords As List(Of String)
        wantedwords = CheckWantedWords()
        For Each item912 In wantedwords
            If Not allwordz.Contains(item912) Then
                sortedwanted.Add(item912)
            End If
        Next
        sortedwanted.Sort()
        For Each item913 In sortedwanted
            If Not item913 = "" AndAlso Not item913 = Environment.NewLine Then
                TextBox10.Text += item913
                TextBox10.Text += Environment.NewLine
            End If
        Next
    End Sub

    Private Sub ProcessAllWords()
        Dim mylists As New List(Of IEnumerable(Of Object))
        mylists = ProcessSentences("", False, False)
        allwordz = New List(Of String)
        Dim wantedwords As List(Of String)
        wantedwords = mylists(2)
        For Each item91 As Nodez In mylists(0)
            If Not allwordz.Contains(item91.text) Then
                allwordz.Add(item91.text)
            End If
        Next
        TextBox11.Text = ""
        allwordz.Sort()
        For Each item911 In allwordz
            TextBox11.Text += item911
            TextBox11.Text += Environment.NewLine
        Next
    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click
        ProcessAllWords()
    End Sub
End Class
